"use client";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { AGENTS } from "@/lib/mockData";
import type { Scenario, AgentStatus } from "@/types";

interface AgentOrchestrationProps {
  scenario: Scenario;
  isRunning: boolean;
  hasRun: boolean;
}

export function AgentOrchestration({ scenario, isRunning, hasRun }: AgentOrchestrationProps) {
  const [agentStates, setAgentStates] = useState<Record<string, AgentStatus>>({});

  useEffect(() => {
    if (!isRunning) {
      if (hasRun) {
        const done: Record<string, AgentStatus> = {};
        AGENTS.forEach((a) => {
          done[a.id] = scenario.agents.includes(a.id) ? "complete" : "idle";
        });
        setAgentStates(done);
      } else {
        setAgentStates({});
      }
      return;
    }

    // Animate agents in sequence
    const active = ["planner", ...scenario.agents.filter((a) => a !== "planner")];
    let i = 0;
    const interval = setInterval(() => {
      if (i >= active.length) { clearInterval(interval); return; }
      const agentId = active[i];
      setAgentStates((prev) => ({ ...prev, [agentId]: "active" }));
      // Mark previous as complete
      if (i > 0) {
        const prev = active[i - 1];
        setAgentStates((s) => ({ ...s, [prev]: "complete" }));
      }
      i++;
    }, 600);
    return () => clearInterval(interval);
  }, [isRunning, hasRun, scenario.agents]);

  const getStatusStyle = (agentId: string) => {
    const status = agentStates[agentId];
    if (status === "active")   return "bg-cyan-500/20 border-cyan-500/60 agent-active";
    if (status === "complete") return "bg-emerald-500/10 border-emerald-500/40";
    if (status === "idle")     return "bg-white/3 border-white/10 opacity-40";
    return "bg-white/3 border-white/10";
  };

  const getStatusDot = (agentId: string) => {
    const status = agentStates[agentId];
    if (status === "active")   return "bg-cyan-400 animate-pulse";
    if (status === "complete") return "bg-emerald-400";
    return "bg-slate-600";
  };

  return (
    <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-xl p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-white font-semibold text-sm">Agent Orchestration</h2>
        {isRunning && (
          <span className="text-cyan-400 text-xs flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            Processing…
          </span>
        )}
        {hasRun && !isRunning && (
          <span className="text-emerald-400 text-xs flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            Complete
          </span>
        )}
      </div>

      {/* Planner at top */}
      <div className="mb-4">
        {AGENTS.filter((a) => a.id === "planner").map((agent) => (
          <div
            key={agent.id}
            className={cn(
              "flex items-center gap-3 p-3 rounded-lg border transition-all duration-500",
              getStatusStyle(agent.id)
            )}
          >
            <span className="text-xl">{agent.icon}</span>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-semibold">{agent.name}</p>
              <p className="text-slate-500 text-[11px]">{agent.role}</p>
            </div>
            <span className={cn("w-2 h-2 rounded-full flex-shrink-0", getStatusDot(agent.id))} />
          </div>
        ))}
      </div>

      {/* Connector arrow */}
      <div className="flex justify-center mb-3">
        <div className="flex flex-col items-center gap-0.5">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-px h-1.5 transition-colors duration-300",
                isRunning ? "bg-cyan-500" : "bg-slate-700"
              )}
            />
          ))}
          <div className={cn("text-xs transition-colors", isRunning ? "text-cyan-500" : "text-slate-700")}>▼</div>
        </div>
      </div>

      {/* Sub-agents grid */}
      <div className="grid grid-cols-2 gap-2">
        {AGENTS.filter((a) => a.id !== "planner").map((agent) => {
          const isInvolved = scenario.agents.includes(agent.id);
          return (
            <div
              key={agent.id}
              className={cn(
                "flex items-center gap-2.5 p-2.5 rounded-lg border transition-all duration-500",
                isInvolved ? getStatusStyle(agent.id) : "bg-white/2 border-white/5 opacity-30"
              )}
            >
              <span className="text-base">{agent.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-slate-200 text-xs font-medium truncate">{agent.name}</p>
                <p className="text-slate-600 text-[10px] truncate">{agent.role}</p>
              </div>
              {isInvolved && (
                <span className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", getStatusDot(agent.id))} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
