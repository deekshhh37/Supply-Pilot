"use client";

import { useState } from "react";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Dashboard } from "@/components/dashboard/Dashboard";
import { TopBar } from "@/components/dashboard/TopBar";
import { ScenarioSelector } from "@/components/scenarios/ScenarioSelector";
import { AgentOrchestration } from "@/components/agents/AgentOrchestration";
import { InventoryPanel } from "@/components/dashboard/InventoryPanel";
import { SCENARIOS } from "@/lib/mockData";
import type { ScenarioType } from "@/types";

// Placeholder components
const AnalyticsPanel = () => (
  <div className="space-y-6">
    <div>
      <h2 className="text-2xl font-bold text-white mb-2">📊 Analytics Dashboard</h2>
      <p className="text-slate-400 text-sm">Advanced supply chain analytics and KPI tracking</p>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-lg p-4">
        <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Total Orders</p>
        <p className="text-2xl font-bold text-cyan-400">2,547</p>
        <p className="text-green-400 text-xs mt-2">↑ 12% vs last month</p>
      </div>
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-lg p-4">
        <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Delivery Rate</p>
        <p className="text-2xl font-bold text-green-400">98.3%</p>
        <p className="text-green-400 text-xs mt-2">↑ 2.1% vs last month</p>
      </div>
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-lg p-4">
        <p className="text-slate-400 text-xs uppercase tracking-wider mb-2">Avg Lead Time</p>
        <p className="text-2xl font-bold text-cyan-400">2.4 days</p>
        <p className="text-green-400 text-xs mt-2">↓ 0.3 days improvement</p>
      </div>
    </div>
  </div>
);

const SettingsPanel = () => (
  <div className="space-y-6">
    <div>
      <h2 className="text-2xl font-bold text-white mb-2">⚙️ Settings</h2>
      <p className="text-slate-400 text-sm">Configure your SupplyPilot preferences</p>
    </div>
    <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-lg p-6 space-y-4">
      <div>
        <label className="text-sm text-slate-300 mb-2 block">Organization Name</label>
        <input type="text" placeholder="Your company name" className="w-full px-3 py-2 bg-[#111827] border border-slate-700 rounded text-white text-sm focus:border-cyan-500 outline-none" />
      </div>
      <div>
        <label className="text-sm text-slate-300 mb-2 block">Default Currency</label>
        <select className="w-full px-3 py-2 bg-[#111827] border border-slate-700 rounded text-white text-sm focus:border-cyan-500 outline-none">
          <option>USD</option>
          <option>EUR</option>
          <option>GBP</option>
        </select>
      </div>
      <div>
        <label className="text-sm text-slate-300 mb-2 block">Alert Threshold</label>
        <input type="number" placeholder="Alert level" className="w-full px-3 py-2 bg-[#111827] border border-slate-700 rounded text-white text-sm focus:border-cyan-500 outline-none" />
      </div>
    </div>
  </div>
);

const ProcurementPanel = () => (
  <div className="space-y-6">
    <div>
      <h2 className="text-2xl font-bold text-white mb-2">🛒 Procurement</h2>
      <p className="text-slate-400 text-sm">Manage suppliers and purchase orders</p>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-lg p-4">
        <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">Active Suppliers</p>
        <p className="text-3xl font-bold text-cyan-400 mb-3">24</p>
        <button className="w-full px-3 py-2 bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 rounded text-sm hover:bg-cyan-500/20 transition-colors">
          View Suppliers
        </button>
      </div>
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-lg p-4">
        <p className="text-slate-400 text-xs uppercase tracking-wider mb-3">Pending Orders</p>
        <p className="text-3xl font-bold text-amber-400 mb-3">7</p>
        <button className="w-full px-3 py-2 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded text-sm hover:bg-amber-500/20 transition-colors">
          View Orders
        </button>
      </div>
    </div>
  </div>
);

export default function Home() {
  const [activeView, setActiveView] = useState("dashboard");
  const [activeScenario, setActiveScenario] = useState<ScenarioType>("vendor_delay");
  const [isRunning, setIsRunning] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  // Get scenario data
  const scenario = SCENARIOS[activeScenario];

  const renderView = () => {
    switch (activeView) {
      case "dashboard":
        return <Dashboard activeScenario={activeScenario} onSelectScenario={setActiveScenario} />;

      case "scenarios":
        return (
          <div className="w-full h-full flex flex-col overflow-hidden">
            <TopBar />
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-white mb-2">Scenario Selection</h1>
                <p className="text-slate-400 text-sm">Choose a supply chain scenario to analyze</p>
              </div>
              <ScenarioSelector
                scenario={scenario}
                activeScenario={activeScenario}
                onSelect={setActiveScenario}
              />
            </main>
          </div>
        );

      case "agents":
        return (
          <div className="w-full h-full flex flex-col overflow-hidden">
            <TopBar />
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-white mb-2">Agent Orchestration</h1>
                <p className="text-slate-400 text-sm">View AI agents processing the current scenario</p>
              </div>
              <AgentOrchestration
                scenario={scenario}
                isRunning={isRunning}
                hasRun={hasRun}
              />
            </main>
          </div>
        );

      case "inventory":
        return (
          <div className="w-full h-full flex flex-col overflow-hidden">
            <TopBar />
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
              <div>
                <h1 className="text-2xl font-bold text-white mb-2">Inventory Management</h1>
                <p className="text-slate-400 text-sm">Monitor warehouse stock levels and movements</p>
              </div>
              <InventoryPanel />
            </main>
          </div>
        );

      case "procurement":
        return (
          <div className="w-full h-full flex flex-col overflow-hidden">
            <TopBar />
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
              <ProcurementPanel />
            </main>
          </div>
        );

      case "analytics":
        return (
          <div className="w-full h-full flex flex-col overflow-hidden">
            <TopBar />
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
              <AnalyticsPanel />
            </main>
          </div>
        );

      case "settings":
        return (
          <div className="w-full h-full flex flex-col overflow-hidden">
            <TopBar />
            <main className="flex-1 overflow-y-auto p-6 space-y-6">
              <SettingsPanel />
            </main>
          </div>
        );

      default:
        return <Dashboard activeScenario={activeScenario} onSelectScenario={setActiveScenario} />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#0A0F1E]">
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        activeScenario={activeScenario}
        onSelectScenario={setActiveScenario}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        {renderView()}
      </div>
    </div>
  );
}