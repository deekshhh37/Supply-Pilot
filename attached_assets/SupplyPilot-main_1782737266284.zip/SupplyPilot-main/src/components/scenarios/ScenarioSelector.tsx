"use client";
import { cn } from "@/lib/utils";
import type { Scenario, ScenarioType } from "@/types";
import { SCENARIOS } from "@/lib/mockData";

const SEV_STYLE: Record<string, string> = {
  critical: "status-critical",
  warning:  "status-warning",
  info:     "status-info",
};

interface ScenarioSelectorProps {
  scenario: Scenario;
  activeScenario: ScenarioType;
  onSelect: (s: ScenarioType) => void;
}

export function ScenarioSelector({ scenario, activeScenario, onSelect }: ScenarioSelectorProps) {
  return (
    <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-xl p-5 h-full flex flex-col gap-5">
      {/* Scenario cards */}
      <div>
        <h2 className="text-white font-semibold text-sm mb-3">Active Scenario</h2>
        <div className="grid grid-cols-2 gap-2">
          {(Object.values(SCENARIOS) as Scenario[]).map((s) => (
            <button
              key={s.id}
              onClick={() => onSelect(s.id)}
              className={cn(
                "text-left p-3 rounded-lg border text-xs transition-all duration-200",
                activeScenario === s.id
                  ? "bg-cyan-500/10 border-cyan-500/40 text-white"
                  : "bg-white/3 border-white/8 text-slate-400 hover:border-white/20 hover:text-slate-200"
              )}
            >
              <span className={cn("text-[10px] px-1.5 py-0.5 rounded mb-1.5 inline-block", SEV_STYLE[s.severity])}>
                {s.severity.toUpperCase()}
              </span>
              <p className="font-medium leading-snug">{s.title}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Inputs */}
      <div>
        <h3 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Scenario Inputs</h3>
        <div className="space-y-1.5">
          {Object.entries(scenario.inputs).map(([key, val]) => (
            <div key={key} className="flex items-center justify-between py-1.5 border-b border-white/5 last:border-0">
              <span className="text-slate-500 text-xs">{key}</span>
              <span className="text-slate-200 text-xs font-medium">{val}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Description */}
      <div className="bg-white/3 rounded-lg p-3 mt-auto">
        <p className="text-slate-300 text-xs leading-relaxed">{scenario.description}</p>
      </div>
    </div>
  );
}
