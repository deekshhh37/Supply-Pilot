# SupplyPilot AI — Frontend

Agentic Decision Intelligence Platform for Supply Chain Operations.

---

## Prerequisites

- **Node.js** v18+ (check with `node --version`)
- **npm** v9+ or **yarn** v1.22+

---

## Quick Start

### 1. Install dependencies
```bash
npm install
# or
yarn install
```

### 2. Run the development server
```bash
npm run dev
# or
yarn dev
```

### 3. Open in browser
Navigate to [http://localhost:3000](http://localhost:3000)

---

## Build for Production

```bash
npm run build
npm start
```

---

## Project Structure

```
supplypilot/
├── src/
│   ├── app/
│   │   ├── globals.css          # Global styles & design tokens
│   │   ├── layout.tsx           # Root layout (providers, fonts)
│   │   └── page.tsx             # Entry point → renders Dashboard
│   │
│   ├── components/
│   │   ├── providers/
│   │   │   ├── ThemeProvider.tsx     # next-themes dark mode
│   │   │   └── QueryProvider.tsx     # TanStack Query setup
│   │   │
│   │   ├── dashboard/
│   │   │   ├── Dashboard.tsx         # Main layout shell
│   │   │   ├── Sidebar.tsx           # Left nav + scenario switcher
│   │   │   ├── TopBar.tsx            # Header + status bar
│   │   │   ├── KPIStrip.tsx          # 4-card KPI row
│   │   │   ├── InventoryPanel.tsx    # Inventory status bars
│   │   │   └── DemandChart.tsx       # Recharts area chart
│   │   │
│   │   ├── agents/
│   │   │   └── AgentOrchestration.tsx  # Agent graph + animation
│   │   │
│   │   └── scenarios/
│   │       ├── ScenarioSelector.tsx    # Scenario cards + inputs
│   │       └── PlannerOutput.tsx       # Decision output + NBA
│   │
│   ├── lib/
│   │   ├── mockData.ts           # All 4 scenario data + agents
│   │   └── utils.ts              # cn() helper
│   │
│   └── types/
│       └── index.ts              # TypeScript interfaces
│
├── package.json
├── tailwind.config.ts
├── tsconfig.json
├── next.config.js
└── postcss.config.js
```

---

## Key Features

| Feature | Location |
|---|---|
| 4 Live Scenarios | `ScenarioSelector` + `mockData.ts` |
| Agent Animation | `AgentOrchestration.tsx` |
| Decision Output (NBA) | `PlannerOutput.tsx` |
| Inventory Bars | `InventoryPanel.tsx` |
| Demand vs Forecast Chart | `DemandChart.tsx` |
| KPI Cards | `KPIStrip.tsx` |

---

## Connecting to Your Backend

Replace mock data in `src/lib/mockData.ts` with real API calls.

Example using TanStack Query in any component:

```tsx
import { useQuery } from "@tanstack/react-query";
import axios from "axios";

const { data } = useQuery({
  queryKey: ["scenario", scenarioId],
  queryFn: () => axios.get(`/api/scenarios/${scenarioId}`).then(r => r.data),
});
```

---

## Tech Stack

| Category | Technology |
|---|---|
| Framework | Next.js 15 (App Router) |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Charts | Recharts |
| Animation | CSS + Tailwind |
| State | TanStack Query |
| Notifications | Sonner |
| Theme | next-themes |
