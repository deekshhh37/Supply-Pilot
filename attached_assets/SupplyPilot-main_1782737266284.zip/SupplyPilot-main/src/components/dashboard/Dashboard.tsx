"use client";
import { useState } from "react";
import { TopBar } from "./TopBar";
import { KPIStrip } from "./KPIStrip";
import { ScenarioSelector } from "@/components/scenarios/ScenarioSelector";
import { AgentOrchestration } from "@/components/agents/AgentOrchestration";
import { PlannerOutput } from "@/components/scenarios/PlannerOutput";
import { InventoryPanel } from "./InventoryPanel";
import { DemandChart } from "./DemandChart";
import { OperationsInputWorkspace } from "./OperationsInputWorkspace";
import { SCENARIOS } from "@/lib/mockData";
import type { ScenarioType } from "@/types";

interface DashboardProps {
  activeScenario: ScenarioType;
  onSelectScenario?: (scenario: ScenarioType) => void;
}

export function Dashboard({ activeScenario, onSelectScenario }: DashboardProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [hasRun, setHasRun] = useState(false);

  const scenario = SCENARIOS[activeScenario];

  const handleRunScenario = () => {
    setIsRunning(true);
    setHasRun(false);
    setTimeout(() => {
      setIsRunning(false);
      setHasRun(true);
    }, 3500);
  };

  return (
    <div className="w-full h-full flex flex-col overflow-hidden">
      <TopBar />
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold gradient-text">SupplyPilot AI</h1>
              <p className="text-slate-400 text-sm mt-0.5">Agentic Decision Intelligence for Supply Chain Operations</p>
            </div>
            <button
              onClick={handleRunScenario}
              disabled={isRunning}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:opacity-60 disabled:cursor-not-allowed text-[#0A0F1E] font-semibold text-sm transition-all duration-200 shadow-lg shadow-cyan-500/20"
            >
              {isRunning ? (
                <>
                  <span className="w-3.5 h-3.5 rounded-full border-2 border-[#0A0F1E] border-t-transparent animate-spin" />
                  Agents Running…
                </>
              ) : (
                <>
                  <span className="text-base">⚡</span>
                  Run Scenario
                </>
              )}
            </button>
          </div>

          {/* Operations Input Workspace */}
          <OperationsInputWorkspace />

          {/* KPI Strip */}
          <KPIStrip kpis={scenario.kpis} />

          {/* Main Grid */}
          <div className="grid grid-cols-12 gap-6">
            {/* Scenario Selector */}
            <div className="col-span-12 lg:col-span-5">
              <ScenarioSelector
                scenario={scenario}
                activeScenario={activeScenario}
                onSelect={onSelectScenario || (() => {})}
              />
            </div>

            {/* Agent Orchestration */}
            <div className="col-span-12 lg:col-span-7">
              <AgentOrchestration
                scenario={scenario}
                isRunning={isRunning}
                hasRun={hasRun}
              />
            </div>

            {/* Planner Output */}
            <div className="col-span-12">
              <PlannerOutput
                scenario={scenario}
                isRunning={isRunning}
                hasRun={hasRun}
              />
            </div>

            {/* Bottom Row */}
            <div className="col-span-12 lg:col-span-6">
              <InventoryPanel />
            </div>
            <div className="col-span-12 lg:col-span-6">
              <DemandChart />
            </div>
          </div>
        </main>
      </div>
    );
  }
