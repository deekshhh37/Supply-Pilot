"use client";
import { useState } from "react";
import { SCENARIOS } from "@/lib/mockData";
import type { ScenarioType } from "@/types";

interface OperationsInputWorkspaceProps {
  onAnalyze?: (data: AnalysisData) => void;
}

export interface AnalysisData {
  scenarioType: ScenarioType;
  emailContent: string;
  currentInventory: number;
  customerTier: string;
}

const CUSTOMER_TIERS = ["Bronze", "Silver", "Gold", "Platinum"];

export function OperationsInputWorkspace({ onAnalyze }: OperationsInputWorkspaceProps) {
  const [scenarioType, setScenarioType] = useState<ScenarioType>("vendor_delay");
  const [emailContent, setEmailContent] = useState("");
  const [currentInventory, setCurrentInventory] = useState<number>(120);
  const [customerTier, setCustomerTier] = useState("Gold");
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    // Simulate API call
    setTimeout(() => {
      const data: AnalysisData = {
        scenarioType,
        emailContent,
        currentInventory,
        customerTier,
      };
      onAnalyze?.(data);
      setIsAnalyzing(false);
    }, 800);
  };

  const handleClear = () => {
    setEmailContent("");
    setCurrentInventory(120);
    setCustomerTier("Gold");
  };

  const scenarioOptions = [
    ...Object.entries(SCENARIOS).map(([key, scenario]) => ({
      id: key as ScenarioType,
      label: scenario.title,
    })),
    { id: "other" as ScenarioType, label: "Other Supply Chain Event" },
  ];

  return (
    <div className="bg-gradient-to-br from-[#1a2847] via-[#0f172a] to-[#0a0f1e] border border-cyan-500/20 rounded-lg p-6 shadow-lg shadow-cyan-500/5">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <span className="text-xl">📋</span>
          New Supply Chain Event
        </h2>
        <p className="text-slate-400 text-sm mt-1">Analyze supply chain disruptions and get AI-powered recommendations</p>
      </div>

      {/* Grid Layout */}
      <div className="grid grid-cols-12 gap-6">
        {/* Left Column */}
        <div className="col-span-12 lg:col-span-7 space-y-5">
          {/* Scenario Type */}
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2">
              Scenario Type
            </label>
            <select
              value={scenarioType}
              onChange={(e) => setScenarioType(e.target.value as ScenarioType)}
              className="w-full px-3 py-2.5 bg-[#111827] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-colors"
            >
              {scenarioOptions.map((option) => (
                <option key={option.id} value={option.id}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          {/* Email Content */}
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2">
              Paste Supplier Email / Details
            </label>
            <textarea
              value={emailContent}
              onChange={(e) => setEmailContent(e.target.value)}
              placeholder="Paste your supplier email, alert, or event details here..."
              className="w-full px-3 py-2.5 bg-[#111827] border border-slate-700 rounded-lg text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-colors resize-none h-32"
            />
            <p className="text-[10px] text-slate-500 mt-1.5">Include delay info, inventory status, or any relevant details</p>
          </div>
        </div>

        {/* Right Column */}
        <div className="col-span-12 lg:col-span-5 space-y-5">
          {/* Current Inventory */}
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2">
              Current Inventory Units
            </label>
            <div className="flex items-center gap-3">
              <input
                type="number"
                value={currentInventory}
                onChange={(e) => setCurrentInventory(Math.max(0, parseInt(e.target.value) || 0))}
                className="flex-1 px-3 py-2.5 bg-[#111827] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-colors"
              />
              <span className="text-slate-400 text-sm font-medium">units</span>
            </div>
          </div>

          {/* Customer Tier */}
          <div>
            <label className="block text-xs uppercase tracking-wider text-slate-400 font-semibold mb-2">
              Customer Tier
            </label>
            <select
              value={customerTier}
              onChange={(e) => setCustomerTier(e.target.value)}
              className="w-full px-3 py-2.5 bg-[#111827] border border-slate-700 rounded-lg text-white text-sm focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 transition-colors"
            >
              {CUSTOMER_TIERS.map((tier) => (
                <option key={tier} value={tier}>
                  {tier}
                </option>
              ))}
            </select>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-3">
            <button
              onClick={handleAnalyze}
              disabled={isAnalyzing || !emailContent.trim()}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed text-[#0A0F1E] font-semibold text-sm transition-all duration-200 shadow-lg shadow-cyan-500/20"
            >
              {isAnalyzing ? (
                <>
                  <span className="w-3.5 h-3.5 rounded-full border-2 border-[#0A0F1E] border-t-transparent animate-spin" />
                  Analyzing…
                </>
              ) : (
                <>
                  <span className="text-base">⚡</span>
                  Analyze Situation
                </>
              )}
            </button>
            <button
              onClick={handleClear}
              disabled={isAnalyzing}
              className="px-4 py-2.5 rounded-lg bg-slate-700/50 hover:bg-slate-700 disabled:opacity-50 disabled:cursor-not-allowed text-slate-200 font-medium text-sm transition-colors"
            >
              Clear
            </button>
          </div>
        </div>
      </div>

      {/* Info Footer */}
      <div className="mt-6 pt-4 border-t border-slate-700/50">
        <p className="text-[11px] text-slate-500">
          💡 <span className="text-slate-400">Tip:</span> The more details you provide, the better recommendations you'll receive from our AI agents.
        </p>
      </div>
    </div>
  );
}
