"use client";
import { cn } from "@/lib/utils";
import type { Scenario } from "@/types";

interface PlannerOutputProps {
  scenario: Scenario;
  isRunning: boolean;
  hasRun: boolean;
}

const IMPACT_STYLE: Record<string, string> = {
  high:   "status-critical",
  medium: "status-warning",
  low:    "status-info",
};

export function PlannerOutput({ scenario, isRunning, hasRun }: PlannerOutputProps) {
  const show = hasRun && !isRunning;

  if (!show && !isRunning) {
    return (
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-xl p-8 flex flex-col items-center justify-center text-center">
        <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-3xl mb-4">
          🧠
        </div>
        <p className="text-white font-semibold mb-1">Ready to Analyze</p>
        <p className="text-slate-500 text-sm max-w-xs">
          Select a scenario and click <span className="text-cyan-400">Run Scenario</span> to trigger agent orchestration and get Next Best Actions.
        </p>
      </div>
    );
  }

  if (isRunning) {
    return (
      <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-xl p-8 flex flex-col items-center justify-center text-center">
        <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-3xl mb-4 animate-pulse">
          🧠
        </div>
        <p className="text-white font-semibold mb-1">Planner Agent Reasoning…</p>
        <p className="text-slate-500 text-sm">Orchestrating sub-agents and synthesizing decision intelligence</p>
        <div className="flex items-center gap-1.5 mt-4">
          {[0,1,2].map((i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full bg-cyan-500"
              style={{ animation: `pulse_slow 1.2s ease-in-out ${i * 0.2}s infinite` }}
            />
          ))}
        </div>
      </div>
    );
  }

  const { reasoning, actions } = scenario;
  const confColor =
    reasoning.confidence >= 90 ? "text-emerald-400" :
    reasoning.confidence >= 75 ? "text-amber-400"   : "text-red-400";

  return (
    <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-xl p-5 space-y-5 animate-slide_in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-white font-semibold text-sm flex items-center gap-2">
          <span>🧠</span> Planner Decision Output
        </h2>
        <div className="flex items-center gap-2">
          <span className="text-slate-500 text-xs">Overall Confidence</span>
          <span className={cn("text-xl font-bold", confColor)}>{reasoning.confidence}%</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Reasoning */}
        <div className="space-y-4">
          <div>
            <h3 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Planner Observations</h3>
            <ul className="space-y-2">
              {reasoning.observations.map((obs, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                  <span className="text-cyan-500 mt-0.5 flex-shrink-0">→</span>
                  {obs}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Constraints Applied</h3>
            <ul className="space-y-2">
              {reasoning.constraints.map((c, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs text-slate-400">
                  <span className="text-amber-500 mt-0.5 flex-shrink-0">⚠</span>
                  {c}
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-cyan-500/5 border border-cyan-500/20 rounded-lg p-3">
            <p className="text-cyan-400 text-xs font-semibold mb-1">Recommendation Summary</p>
            <p className="text-slate-300 text-xs leading-relaxed">{reasoning.recommendation}</p>
          </div>

          <div className="flex flex-wrap gap-1.5">
            <span className="text-slate-600 text-[10px]">Evidence:</span>
            {reasoning.evidenceSources.map((src) => (
              <span key={src} className="text-[10px] px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-400">
                {src}
              </span>
            ))}
          </div>
        </div>

        {/* Right: Actions */}
        <div>
          <h3 className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Next Best Actions</h3>
          <div className="space-y-2.5">
            {actions.map((action, i) => (
              <div
                key={action.id}
                className="bg-white/3 border border-white/8 rounded-lg p-3 hover:border-white/20 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-md bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 text-xs font-bold flex-shrink-0">
                    {i + 1}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <p className="text-white text-xs font-semibold">{action.title}</p>
                      <span className={cn("text-[10px] px-1.5 py-0.5 rounded", IMPACT_STYLE[action.impact])}>
                        {action.impact.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-slate-400 text-[11px] leading-relaxed mb-2">{action.description}</p>
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="text-emerald-400 text-[10px] font-medium">{action.confidence}% confidence</span>
                      {action.cost && <span className="text-slate-500 text-[10px]">{action.cost}</span>}
                      {action.timeframe && <span className="text-cyan-500 text-[10px]">{action.timeframe}</span>}
                      <span className="text-slate-600 text-[10px]">via {action.agentSource}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
