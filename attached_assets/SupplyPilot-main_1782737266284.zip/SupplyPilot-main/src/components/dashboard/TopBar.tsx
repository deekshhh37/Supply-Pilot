"use client";
import { useState, useEffect } from "react";

export function TopBar() {
  const [time, setTime] = useState("");

  useEffect(() => {
    const update = () => {
      setTime(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="h-14 border-b border-[#1E3A5F] bg-[#111827]/80 backdrop-blur-sm flex items-center justify-between px-6 flex-shrink-0">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-emerald-400 text-xs font-medium">All Agents Online</span>
        </div>
        <span className="text-slate-700">|</span>
        <span className="text-slate-400 text-xs">9 agents active</span>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-slate-500 text-xs font-mono">{time}</span>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-amber-500/10 border border-amber-500/20">
          <span className="text-amber-400 text-xs font-medium">⚠ 2 alerts pending</span>
        </div>
        <button className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors">
          🔔
        </button>
      </div>
    </header>
  );
}
