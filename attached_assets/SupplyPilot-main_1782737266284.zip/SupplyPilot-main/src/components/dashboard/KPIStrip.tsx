"use client";
import { cn } from "@/lib/utils";
import type { KPI } from "@/types";

const COLOR_MAP: Record<string, { text: string; bg: string; border: string }> = {
  red:   { text: "text-red-400",    bg: "bg-red-500/10",    border: "border-red-500/20"   },
  amber: { text: "text-amber-400",  bg: "bg-amber-500/10",  border: "border-amber-500/20" },
  green: { text: "text-emerald-400",bg: "bg-emerald-500/10",border: "border-emerald-500/20"},
  cyan:  { text: "text-cyan-400",   bg: "bg-cyan-500/10",   border: "border-cyan-500/20"  },
};

interface KPIStripProps { kpis: KPI[] }

export function KPIStrip({ kpis }: KPIStripProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {kpis.map((kpi, i) => {
        const c = COLOR_MAP[kpi.color ?? "cyan"];
        return (
          <div
            key={i}
            className={cn("rounded-xl border p-4 card-hover", c.bg, c.border)}
          >
            <p className="text-slate-400 text-xs font-medium mb-1">{kpi.label}</p>
            <div className="flex items-baseline gap-1.5">
              <span className={cn("text-2xl font-bold", c.text)}>
                {kpi.value}
              </span>
              {kpi.unit && <span className="text-slate-500 text-xs">{kpi.unit}</span>}
            </div>
            {kpi.trendValue && (
              <p className="text-slate-500 text-[11px] mt-1">{kpi.trendValue}</p>
            )}
          </div>
        );
      })}
    </div>
  );
}
