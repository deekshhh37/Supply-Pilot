export type ScenarioType = "vendor_delay" | "inventory_shortage" | "weather_risk" | "high_value_customer";

export type AgentStatus = "idle" | "thinking" | "active" | "complete" | "error";

export interface Agent {
  id: string;
  name: string;
  role: string;
  status: AgentStatus;
  icon: string;
  lastAction?: string;
  confidence?: number;
}

export interface Action {
  id: string;
  priority: number;
  title: string;
  description: string;
  impact: "high" | "medium" | "low";
  confidence: number;
  cost?: string;
  timeframe?: string;
  agentSource: string;
}

export interface PlannerReasoning {
  observations: string[];
  constraints: string[];
  recommendation: string;
  confidence: number;
  evidenceSources: string[];
}

export interface Scenario {
  id: ScenarioType;
  title: string;
  description: string;
  severity: "critical" | "warning" | "info";
  inputs: Record<string, string | number>;
  agents: string[];
  actions: Action[];
  reasoning: PlannerReasoning;
  kpis: KPI[];
}

export interface KPI {
  label: string;
  value: string | number;
  unit?: string;
  trend?: "up" | "down" | "flat";
  trendValue?: string;
  color?: string;
}

export interface InventoryItem {
  product: string;
  warehouse: string;
  current: number;
  reorder: number;
  max: number;
  status: "ok" | "low" | "critical";
}

export interface ChartDataPoint {
  name: string;
  value: number;
  forecast?: number;
  reorder?: number;
}
