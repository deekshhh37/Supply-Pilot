"use client";
import { cn } from "@/lib/utils";
import type { ScenarioType } from "@/types";

const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: "⬡" },
  { id: "scenarios", label: "Scenarios", icon: "⚡" },
  { id: "agents", label: "Agents", icon: "🤖" },
  { id: "inventory", label: "Inventory", icon: "📦" },
  { id: "procurement", label: "Procurement", icon: "🛒" },
  { id: "analytics", label: "Analytics", icon: "📊" },
  { id: "settings", label: "Settings", icon: "⚙️" },
];

const SCENARIO_BADGES: { id: ScenarioType; label: string; severity: string }[] = [
  { id: "vendor_delay",         label: "Vendor Delay",     severity: "critical" },
  { id: "inventory_shortage",   label: "Inv. Shortage",    severity: "warning"  },
  { id: "weather_risk",         label: "Weather Risk",     severity: "warning"  },
  { id: "high_value_customer",  label: "VIP Customer",     severity: "info"     },
];

const SEV_COLOR: Record<string, string> = {
  critical: "bg-red-500",
  warning:  "bg-amber-500",
  info:     "bg-cyan-500",
};

interface SidebarProps {
  activeView?: string;
  setActiveView?: (view: string) => void;
  activeScenario?: ScenarioType;
  onSelectScenario?: (s: ScenarioType) => void;
}

export function Sidebar({ activeView = "dashboard", setActiveView, activeScenario, onSelectScenario }: SidebarProps) {
  return (
    <aside className="w-60 flex-shrink-0 bg-[#111827] border-r border-[#1E3A5F] flex flex-col">
      {/* Logo */}
      <div className="p-5 border-b border-[#1E3A5F]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-sm">
            🚀
          </div>
          <div>
            <p className="text-white font-bold text-sm leading-none">SupplyPilot</p>
            <p className="text-slate-500 text-[10px] mt-0.5">AI Decision Platform</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView?.(item.id)}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-left",
              activeView === item.id
                ? "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            )}
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}

        {/* Scenarios section */}
        <div className="pt-4 pb-1 px-3">
          <p className="text-[10px] uppercase tracking-widest text-slate-600 font-semibold">Live Scenarios</p>
        </div>
        {SCENARIO_BADGES.map((s) => (
          <button
            key={s.id}
            onClick={() => {
              if (onSelectScenario) {
                onSelectScenario(s.id);
              }
            }}
            className={cn(
              "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors text-left",
              activeScenario === s.id
                ? "bg-white/8 text-white border border-white/10"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
            )}
          >
            <span className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", SEV_COLOR[s.severity])} />
            {s.label}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-[#1E3A5F]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-full bg-purple-500/30 flex items-center justify-center text-xs">
            SC
          </div>
          <div>
            <p className="text-white text-xs font-medium">Supply Chain Ops</p>
            <p className="text-slate-500 text-[10px]">Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
