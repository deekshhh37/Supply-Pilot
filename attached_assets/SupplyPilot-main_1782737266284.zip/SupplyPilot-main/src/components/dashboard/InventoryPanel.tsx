"use client";
import { cn } from "@/lib/utils";
import { INVENTORY_DATA } from "@/lib/mockData";

const STATUS_STYLE: Record<string, string> = {
  critical: "status-critical",
  low:      "status-warning",
  ok:       "status-success",
};

export function InventoryPanel() {
  return (
    <div className="bg-[#1A2235] border border-[#1E3A5F] rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-white font-semibold text-sm">Inventory Status</h2>
        <span className="text-slate-500 text-xs">Live · 5 warehouses</span>
      </div>
      <div className="space-y-3">
        {INVENTORY_DATA.map((item) => {
          const pct = Math.round((item.current / item.max) * 100);
          const barColor =
            item.status === "critical" ? "bg-red-500" :
            item.status === "low"      ? "bg-amber-500" : "bg-emerald-500";
          return (
            <div key={item.product}>
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-slate-200 text-xs font-medium">{item.product}</span>
                  <span className={cn("text-[10px] px-1.5 py-0.5 rounded", STATUS_STYLE[item.status])}>
                    {item.status.toUpperCase()}
                  </span>
                </div>
                <span className="text-slate-400 text-xs">{item.current} / {item.max}</span>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div
                  className={cn("h-full rounded-full transition-all duration-700", barColor)}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <p className="text-slate-600 text-[10px] mt-0.5">{item.warehouse} · Reorder at {item.reorder}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
